package com.example.lab06;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView mListView;
    private PhoneAdapter mAdapter;
    private List<Phone> mData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        initData();
    }

    private void initViews() {
        mListView = findViewById(R.id.listView);
    }

    private void initData() {
        mData = new ArrayList<>();
        mData.add(new Phone(R.drawable.mobile, "Apple"));
        mData.add(new Phone(R.drawable.mobile2, "Samsung"));
        mData.add(new Phone(R.drawable.mobile3, "Nokia"));
        mData.add(new Phone(R.drawable.mobile, "Oppo"));
        mData.add(new Phone(R.drawable.mobile2, "HTC"));
        mData.add(new Phone(R.drawable.mobile3, "Google"));
        mData.add(new Phone(R.drawable.mobile, "Microsoft"));
        mData.add(new Phone(R.drawable.mobile2, "BKav"));
        mData.add(new Phone(R.drawable.mobile3, "VinSmart"));

        mAdapter = new PhoneAdapter(this, R.layout.row_layout, mData);
        mListView.setAdapter(mAdapter);
    }
}
